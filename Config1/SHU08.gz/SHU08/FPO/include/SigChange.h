#ifndef SigChangeH
#define SigChangeH

extern char *pRN17D02NN;
extern char *pRN17D02SA1;
extern char *pRN17D02SA2;
extern char *pRN17D02SGMN;
extern char *pRN17D02SGP;
extern char *pRN17D02SYMN;
extern char *pRN17D02SYP;
extern char *pRN17D03NN;
extern char *pRN17D03SA1;
extern char *pRN17D03SA2;
extern char *pRN17D03SGMN;
extern char *pRN17D03SGP;
extern char *pRN17D03SYMN;
extern char *pRN17D03SYP;
extern char *pRQ13S01NN;
extern char *pRQ13S01SA1;
extern char *pRQ13S01SA2;
extern char *pRQ13S01SG;
extern char *pRQ13S01SGM;
extern char *pRQ13S01SGR;
extern char *pRQ13S01SO;
extern char *pRQ13S01SY;
extern char *pRQ13S01SYM;
extern char *pRQ13S01SYR;
extern char *pRQ13S01SZ;
extern void Read_Sig();
extern void Write_Sig();
extern void Init_P();
#endif
