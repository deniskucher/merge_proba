#ifndef LIBRARYH
#define LIBRARYH
#include "usertype.h"
#include "uIncludes.h"

smallint _ROUND(const float number);
void _BYSTRO1(smallint TCBYS, bool PBYS, smallint TBYS, smallint SM, smallint TMABYS, bool BYS);
void _BYSTRO2(smallint TCBYS, bool PBYS, smallint TBYS, smallint SM, smallint TMABYS, bool BYS);
void _LIBRARY();

#endif
