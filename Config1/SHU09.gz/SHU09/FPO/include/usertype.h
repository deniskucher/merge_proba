#ifndef usertypeH
#define usertypeH
#include "Sinlib.h"
#include "uIncludes.h"

#endif
