#ifndef uObjectH
#define uObjectH
#include "usertype.h"
#include "uclasses.h"

extern _TMIG *_PI21AC01;
extern _TMIG *_PI21AD03;
extern _TMIG *_PI21AE05;

extern _TTAKT *_takt_tc;

extern void InitObjects();
extern void DeleteObjects();

#endif


