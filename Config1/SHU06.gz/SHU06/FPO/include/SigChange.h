#ifndef SigChangeH
#define SigChangeH

extern char *pAA11AA12;
extern char *pPI12AB01DTS;
extern char *pPI12AB01TS;
extern char *pPI12AB05DTS;
extern char *pPI12AB05TS;
extern char *pPI12AB09DTS;
extern char *pPI12AB09TS;
extern char *pPI12AG03KNMC;
extern char *pPI12AG05KNMG;
extern void Read_Sig();
extern void Write_Sig();
extern void Init_P();
#endif
