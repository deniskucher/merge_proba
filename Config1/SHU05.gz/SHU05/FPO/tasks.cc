#include "tasks.h"
#include "ZDMSH.h"

void _TaskFPO()
{
  _ZDMSH();
}

