#ifndef uIncludesH
#define uIncludesH
#include <math.h>
#include <stdlib.h>
#include <iostream>
#endif
