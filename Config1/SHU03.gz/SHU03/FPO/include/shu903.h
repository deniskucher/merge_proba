#ifndef shu903H
#define shu903H
#include "usertype.h"
#include "uIncludes.h"

void _FILTR();
void _BLOK_ZD();
void _AVR();
void _TC();
void _shu903();

#endif
