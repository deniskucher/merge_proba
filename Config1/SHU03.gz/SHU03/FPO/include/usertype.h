#ifndef usertypeH
#define usertypeH
#include "Sinlib.h"


#endif
